import logo from './logo.png';

export  {
  logo,
}