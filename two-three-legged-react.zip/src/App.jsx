import './styles/index.css'
import { Home } from './pages/public/'
function App() {

  return (
    <>  
      <Home />
    </>
  )
}

export default App
