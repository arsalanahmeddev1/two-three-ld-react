
import React from 'react'
import Layout from '../../components/layout/Layout'
import {Header, HeroBanner, FeaturedProfile, FilterArtist, LoveArt} from '../../components';
const Home = () => {
  return (
    <Layout>
      <Header />
      <HeroBanner />
      <FeaturedProfile />
      <FilterArtist />
      <LoveArt />
    </Layout>
  )
}

export default Home
