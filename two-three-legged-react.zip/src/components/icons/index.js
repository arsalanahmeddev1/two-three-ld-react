import { CgProfile } from "react-icons/cg";
import { FaRegHeart } from "react-icons/fa";
import { FiSearch } from "react-icons/fi";

export  {
  CgProfile,
  FaRegHeart,
  FiSearch,
}