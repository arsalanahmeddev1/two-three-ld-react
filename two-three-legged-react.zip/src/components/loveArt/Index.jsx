import React from 'react'
import { Title, Para } from '../ui'


const Index = () => {
  return (
    <section className='love-art-sec pb-[40px]'>
      <div className="container">
        <Title className='mx-auto max-w-[1020px] mb-[40px]' title='Love Art? Connect with an artist and their work'/>
        <Para clasname="text-black text-[20px] max-w-[540px] mx-auto text-center" title="Each 23LD artist is unique in their own way just like art. Learn their story and their life's work"/>

      </div>
    </section>
  )
}

export default Index
