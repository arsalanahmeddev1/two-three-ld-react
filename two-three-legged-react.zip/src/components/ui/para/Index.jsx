import React from 'react'

const Index = ({title, clasname}) => {
  return <p className={`font-poppins ${clasname}`}>{title}</p>
}

export default Index
