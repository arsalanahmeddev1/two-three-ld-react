import Input from './Input';
import Title from './title';
import SelectDropdown from './select';
import Para from './para';
export {
  Input,
  Title,
  SelectDropdown,
  Para,
}