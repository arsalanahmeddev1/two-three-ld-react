import React from 'react'
import clsx from 'clsx';
const Index = ({ title, className}) => {
  return <h2 className={clsx('text-[55px] font-bold text-center text-black', className)}>{title}</h2>
}

export default Index
