export const nav = [
  {
    id: 1,
    title: 'Market Place',
    path: '/',
  },
  {
    id: 2,
    title: 'Community Partners',
    path: '/about',
  },
  {
    id: 3,
    title: 'Work with Us',
    path: '/about',
  },
  {
    id: 4,
    title: 'Work with Us',
    path: '/about',
  },
]

export const heroBanner = {
  title: 'Discover. Connect. Collect.',
  description: 'Source local art for your home or business.',
}

// export const artist = [
//   {
//     id: 1,
//     name: 'Devin Pughsley',
//     image: '/images/featured-img-01.png',
//   },
//   {
//     id: 2,
//     name: 'Robbie Lasky',
//     image: '/images/featured-img-01.png',
//   },
//   {
//     id: 3,
//     name: 'Luke Joshu',
//     image: '/images/featured-img-01.png',
//   },
  
// ]